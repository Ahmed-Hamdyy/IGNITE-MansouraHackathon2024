from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from sqlalchemy.exc import IntegrityError
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os

# Flask application setup
app = Flask(__name__)
app.secret_key = 'ahmed111'

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'

# Database initialization
db = SQLAlchemy(app)

# Login manager setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    national_id = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    profile_photo = db.Column(db.String(150), nullable=True)
    skills = db.Column(db.String(300), nullable=False)
    role = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    availability = db.Column(db.String(100), nullable=False)

class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.String(500), nullable=False)
    skills = db.Column(db.String(300), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('jobs', lazy=True))

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=db.func.current_timestamp())

# Create the database if it does not exist
with app.app_context():
    db.drop_all()
    db.create_all()

# User loader for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        national_id = request.form['national_id']
        password = request.form['password']
        skills = ','.join(request.form.getlist('skills'))  # Combine skills into a string
        role = request.form['role']
        location = request.form['location']
        availability = request.form['availability']
        profile_photo = request.files['profile_photo']

        if User.query.filter_by(email=email).first():
            flash('Email already registered. Please use another email.', 'danger')
            return redirect(url_for('signup'))

        if User.query.filter_by(national_id=national_id).first():
            flash('National ID already registered. Please use another ID.', 'danger')
            return redirect(url_for('signup'))

        # Save profile photo
        photo_filename = None
        if profile_photo:
            if not os.path.exists(app.config['UPLOAD_FOLDER']):
                os.makedirs(app.config['UPLOAD_FOLDER'])
            photo_filename = secure_filename(profile_photo.filename)
            profile_photo.save(os.path.join(app.config['UPLOAD_FOLDER'], photo_filename))

        hashed_password = generate_password_hash(password)
        new_user = User(
            name=name,
            email=email,
            national_id=national_id,
            password=hashed_password,
            skills=skills,
            role=role,
            location=location,
            availability=availability,
            profile_photo=photo_filename
        )

        try:
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user)
            flash('Account created successfully!', 'success')
            return redirect(url_for('main'))
        except IntegrityError:
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('main'))
        else:
            flash('Invalid email or password.', 'danger')

    return render_template('index.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/main')
@login_required
def main():
    users = User.query.filter(User.id != current_user.id).all()
    return render_template('main.html', users=users)

@app.route('/account')
@login_required
def account():
    user_info = {
        "name": current_user.name,
        "email": current_user.email,
        "profile_photo": current_user.profile_photo,
        "skills": current_user.skills.split(','),  # Convert skills string to a list
        "role": current_user.role,
        "location": current_user.location,
        "availability": current_user.availability
    }
    return render_template('account.html', user=user_info)

@app.route('/chat/<int:user_id>', methods=['GET', 'POST'])
@login_required
def chat(user_id):
    receiver = User.query.get_or_404(user_id)

    messages = Message.query.filter(
        ((Message.sender_id == current_user.id) & (Message.receiver_id == user_id)) |
        ((Message.sender_id == user_id) & (Message.receiver_id == current_user.id))
    ).order_by(Message.timestamp).all()

    if request.method == 'POST':
        content = request.form['message']
        if content.strip():
            new_message = Message(sender_id=current_user.id, receiver_id=user_id, content=content)
            db.session.add(new_message)
            db.session.commit()
            return redirect(url_for('chat', user_id=user_id))

    return render_template('chat.html', receiver=receiver, messages=messages)

if __name__ == '__main__':
    app.run(debug=False)
