/** 
// Redirect to Sign-Up page when "أنشئ حساب" is clicked
document.getElementById('signup-link')?.addEventListener('click', function (e) {
    e.preventDefault(); // Prevent default link behavior
    window.location.href = "/signup.html"; // Redirect to Sign-Up page
});
**/

// Redirect to Main page after Sign-Up form submission
document.getElementById('signup-form')?.addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent form submission for demonstration
    window.location.href = "/main.html"; // Redirect to Main page
});
   // ربط الشعار بالشات بوت
  /**
  document.getElementById("chatbot-logo").addEventListener("click", function () {
    var chatbotSection = document.getElementById("chatbot-section");

    if (chatbotSection.style.display === "none" || chatbotSection.style.display === "") {
        chatbotSection.style.display = "block"; // إظهار الشات بوت
        setTimeout(function () {
            chatbotSection.classList.add("open"); // Add the 'open' class after the element is displayed
        }, 10); // Delay to allow the display change to take effect
    } else {
        chatbotSection.classList.remove("open"); // Remove the 'open' class to shrink the chat
        setTimeout(function () {
            chatbotSection.style.display = "none"; // Hide the chatbot after transition
        }, 300); // Delay to allow the transition to complete
    }
}); 
**/

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("chatbot-logo").addEventListener("click", function () {
        var chatbotSection = document.getElementById("chatbot-section");

        if (chatbotSection.style.display === "none" || chatbotSection.style.display === "") {
            chatbotSection.style.display = "block";
            setTimeout(function () {
                chatbotSection.classList.add("open");
            }, 10);
        } else {
            chatbotSection.classList.remove("open");
            setTimeout(function () {
                chatbotSection.style.display = "none";
            }, 300);
        }
    });
});
<script>
    function viewDetails(userId) {
        // تأكد أن الرابط يشير إلى المسار الصحيح
        window.location.href = `/account/${userId}`;
    }
</script>
