// Add and Remove Skills
document.querySelector('.add-skill-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const skillInput = this.querySelector('input');
    const skillValue = skillInput.value.trim();

    if (skillValue) {
        const skillsList = document.querySelector('.skills-list');
        const skillElement = document.createElement('span');
        skillElement.className = 'skill';
        skillElement.textContent = skillValue;

        // Append the skill
        skillsList.appendChild(skillElement);
        skillInput.value = '';
    } else {
        alert('Please enter a skill.');
    }
});
